# RNA-seq ML Classifier

Using Random Forest to predict sample phenotypes from gene expression.

## What I did

Tried to predict genotype, sex, and treatment from RNA-seq data. Wanted to see which biological variables have the strongest effect on gene expression.

## Results

| Target | Accuracy |
|--------|----------|
| Sex | **80%** |
| Treatment | 66% |
| Genotype | 42% |

Sex is the easiest to predict — makes sense given X/Y chromosome differences and hormones. Genotype (WT vs Cre) can't really be predicted, meaning the Cre modification doesn't cause huge transcriptional changes.

![results](results.png)

## Top genes for sex prediction

| Gene | Importance |
|------|------------|
| Grp | 0.02 |
| Srd5a2 | 0.02 |
| Fjx1 | 0.018 |
| Slc12a9 | 0.018 |
| Ccdc141 | 0.018 |

## Data

- 24 mouse samples
- ~18k genes (after filtering low expression and removing Gm genes)
- Balanced design

## How to run

```bash
pip install pandas numpy scikit-learn matplotlib
python ml_classifier.py
```

Needs `annotation.txt` and `count.txt` in same folder.

## Files

- `ml_classifier.py` - main script
- `annotation.txt` - sample metadata
- `count.txt` - featureCounts output
- `results.png` - plots
- `top_genes.csv` - top 50 predictive genes
- `requirements.txt` - dependencies

## What I learned

- Sex differences dominate gene expression patterns
- ML needs lots of samples to work well (24 is pretty small)
- Cross-validation gives more reliable results than single train/test split
- Removing unannotated genes (Gm) cleans up the results
